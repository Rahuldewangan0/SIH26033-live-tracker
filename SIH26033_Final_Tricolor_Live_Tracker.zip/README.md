# SIH26033 Live Tracker

Dark tricolour live tracker for SIH26033.

Includes the Smart India Hackathon header, Ministry of Consumer Affairs, Food & Public Distribution, tricolour background, live counter UI, trend graph, and a Vercel API endpoint.

Deploy the whole folder/repository to Vercel. The frontend polls `/api/sih?ps=SIH26033` every 60 seconds.
